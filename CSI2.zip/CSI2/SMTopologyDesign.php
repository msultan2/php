
<!--start style of toplogy -->
		  <link rel="stylesheet" href="./css/jsPlumbToolkit-defaults.css">
        <link rel="stylesheet" href="./cs2s/main.css">
        <link rel="stylesheet" href="./css/jsPlumbToolkit-demo.css">
        <link rel="stylesheet" href="./css/demo.css">
		
		
<!--end toplogy -->


<div id="e_myWorld_mainPage_ajax" style="">
	<div class="＿bea-wlp-disc-context-hook" id="disc_655f6d79576f726c645f6d61696e50616765" >
		<div id="myWorld_mainPage" class="wlp-bighorn-page">
		
		
		
		
<div class="container-fluid">






        




  
  
  
  
  









<div class="row">
  <div class="col-md-11">
  
  
  <!--start table in side tab -->

  
	        <div class="container-fluid">
           
			 <div class="row">
			 <h6> Service Topology</h6>
			 </div>
			  <div class="row">

			  
			  <!-- start the toplogy -->
			  
			  
			  
			  
			  	
    <body data-demo-id="perimeterAnchors" data-library="dom">
	

	
        <div id="jtk-demo-main">
            <!-- demo -->
            <div class="jtk-demo-canvas canvas-wide perimeter-demo jtk-surface jtk-surface-nopan" id="canvas">
                <div class="shape" data-shape="Rectangle">Rectangle</div>
                <div class="shape" data-shape="Ellipse">Ellipse</div>
                <div class="shape" data-shape="Circle">Circle</div>
                <div class="shape" data-shape="Diamond">Diamond</div>
	
                <div class="shape" data-shape="Triangle" style="left:700px;top:380px;">Triangle</div>
                <div class="shape _90" data-shape="Triangle" data-rotation="90" style="left:60px;top:500px;">90&#176; rotation</div>
            </div>
            <!-- /demo -->
            <!-- explanation -->
           
            <!-- /explanation -->
        </div>

<!-- JS -->
        <!-- support lib for bezier stuff -->
        <script src="./lib/jsBezier-0.7.js"></script>
        <!-- event adapter -->
		<script src="./lib/mottle-0.6.js"></script>
		<!-- geometry functions -->
        <script src="./lib/biltong-0.2.js"></script>
		<!-- drag -->
        <script src="./lib/katavorio-0.8.js"></script>
        <!-- jsplumb util -->
        <script src="./src/util.js"></script>
        <script src="./src/browser-util.js"></script>
        <!-- main jsplumb engine -->
        <script src="./src/jsPlumb.js"></script>
        <!-- base DOM adapter -->
        <script src="./src/dom-adapter.js"></script>
        <script src="./src/overlay-component.js"></script>
        <!-- endpoint -->
        <script src="./src/endpoint.js"></script>
        <!-- connection -->
        <script src="./src/connection.js"></script>
        
		
		
		<!-- anchors -->
        <script src="./src/anchors.js"></script>
        <!-- connectors, endpoint and overlays  -->
        <script src="./src/defaults.js"></script>
        <!-- bezier connectors -->
        <script src="./src/connectors-bezier.js"></script>
      



	  <!-- state machine connectors -->
        <script src="./src/connectors-statemachine.js"></script>
        <!-- flowchart connectors -->
        <script src="./src/connectors-flowchart.js"></script>
        <!-- SVG renderer -->
        <script src="./src/renderers-svg.js"></script>


        <!-- vml renderer -->
        <script src="./src/renderers-vml.js"></script>

        <!-- common adapter -->
        <script src="./src/base-library-adapter.js"></script>
        <!-- no library jsPlumb adapter -->
        <script src="./src/dom.jsPlumb.js"></script>
        <!-- /JS -->

		
		
		
		
		
		
		
   
		<!--  demo code -->
		<script src="./js/demo.js"></script>



    </body>

	
	
	
			  <!-- end topology -->
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
			  
            </div><!--row end -->
			
			
			
        </div>
	
	
	<!--end table indide tab-->
	
	
	
  
  </div>

</div>
        
     </div>  <!-- end container  -->   
        
        
		
		
		</div>
	</div>
</div>
            

        
        
        
        



<!-- End additional plugins -->

<!---end these this scripts for animating th charts -->	
	<!--  script type="text/javascript" src="example.min.js"></script-->
			