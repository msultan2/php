<link rel="stylesheet" type="text/css" href="css/style.css" />
		
		
		
		
		
		
			
			<div class="content"style="text-align: center;">
				<?php echo $errorMsg ;?>
				<div class="clear"></div>
			</div>
			
			
			
			<!-- The JavaScript -->
		