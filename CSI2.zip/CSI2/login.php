<?php
include 'header.html';
include 'index.html';
include 'footer.html';

