<?php 
echo "fromtest";