<?php include 'select_list.php'; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<title>Multiple Select Dropdown list with Ajax</title>
<script src="ajax_select.js" type="text/javascript"></script>
</head>
<body>
<h1>Multiple Select Dropdown list with Ajax</h1><br/>

<form action="" method="post">
Select: <?php echo $re_html; ?>
</form>

<br/><br/><br/><a href="http://coursesweb.net/" title="Courses for web programming and development">CoursesWeb.net</a>
</body>
</html>