<?php include ("template.php"); ?>
<div id="content">
                	hiiii
        		</div>
<?php include ("footer.html"); ?>
				