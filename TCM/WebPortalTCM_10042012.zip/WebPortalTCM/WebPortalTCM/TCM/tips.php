<?php include ("template.php"); ?>
<div id="content">
	<div class="razd_lr">
		<div id="right">
			<h1>Tips:</h1>
			<div style="height:15px;"></div>
			The change initiatir's <b>Manager approval is required</b> to move the change request to the next phase.
			<div class="razd_h"></div>
			<h1>Risk:</h1>
			<div style="height:15px;"></div>
			<table class="blue" width=80% >
				<tr><th>Risk Level</th><th>Impact</th><th>Probability</th></tr>
				<tr>
					<td>Level1</td>
					<td colspan=2>No Service Impact</td>
				</tr>
				<tr>
					<td>Level2</td>
					<td>Low</td>
					<td>Low</td>
				</tr>
				<tr>
					<td>Level3</td>
					<td>Low</td>
					<td>High</td>					
				</tr>
				<tr>
					<td>Level4</td>
					<td><b>High</b></td>
					<td>Low</td>					
				</tr>
				<tr>
					<td>Level5</td>
					<td><b>High</b></td>
					<td><b>High</b></td>
				</tr>
			</table>
		</div>
		<div id="left">
			<h1>Urgency:</h1>
			<div style="height:15px;"></div>
			<table class="blue" >
				<tr><th>Urgency</th><th>Time Frame</th><th>Description</th></tr>
				<tr>
					<td>Critical</td>
					<td><b>quickly</b></td>
					<td class=left><ul>
							<li>recover an <b>available service</b></li>
							<li>deploy a <b>commercial strategic</b> roll out</li>
						</ul>
					</td>
				</tr>
				<tr>
					<td>High</td>
					<td><b>quickly</b></td>
					<td class=left><ul>
							<li>recover an <b>affected service</b></li>
						</ul>
					</td>
				</tr>
						<tr>
					<td>Medium</td>
					<td>appropraite</td>
					<td class=left><ul>
							<li>deploy a <b>new service</b></li>
							<li>recover service that is <b>not severly impacted</b></li>
							<li><b>upgrade a system</b> or enhance service feature</li>
						</ul>
					</td>
				</tr>
						<tr>
					<td>Low</td>
					<td>appropraite</td>
					<td class=left><ul>
							<li>recover a service that is degraded but still available</li>
						</ul>
					</td>
				</tr>
			</table>
			<div style="height:20px;"></div>
			<h1>Impact:</h1>
			<div style="height:15px;"></div>
			<table class="blue" >
				<tr><th>Impact</th><th>CAB authorization</th><th>Impacted Subscribers</th><th>Impacted VAS customers</th><th>Revenue Risk</th></tr>
				<tr>
					<td>Extensive</td>
					<td><b>Required</b></td>
					<td>>25%</td>
					<td>>1%</td>
					<td>>250K LE</td>
				</tr>
				<tr>
					<td>Significant</td>
					<td><b>Required</b></td>
					<td>>1 5%</td>
					<td>>0.5%</td>
					<td>>51K LE</td>
				</tr>
						<tr>
					<td>Moderate</td>
					<td>Not Required</td>
					<td>>10%</td>
					<td><0.5%</td>
					<td>>1K LE</td>
				</tr>
						<tr>
					<td>Minor</td>
					<td colspan=4>A change with no impact on operational services</td>
				</tr>
			</table>
		</div>
		<div style="clear: both"></div>
	</div>
</div>
<?php include ("footer.html"); ?>
				